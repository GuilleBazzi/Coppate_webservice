<?php
/**
 * Provee las constantes para conectarse a la base de datos
 * Mysql.
 */
define("HOSTNAME", "localhost");// Nombre del host
define("DATABASE", "hidden"); // Nombre de la base de datos
define("USERNAME", "hidden"); // Nombre del usuario
define("PASSWORD", "hidden"); // Nombre de la constrase�a
?>