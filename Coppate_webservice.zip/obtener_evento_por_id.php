<?php
/**
 * Obtiene el detalle de una evento especificada por
 * su identificador "idEvento"
 */

require 'Evento.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET') {

    if (isset($_GET['idEvento'])) {

        // Obtener par�metro idEvento
        $parametro = $_GET['idEvento'];

        // Tratar retorno
        $retorno = Evento::getById($parametro);


        if ($retorno) {

            $evento["estado"] = "1";
            $evento["evento"] = $retorno;
            // Enviar objeto json de la evento
            print json_encode($evento);
        } else {
            // Enviar respuesta de error general
            print json_encode(
                array(
                    'estado' => '2',
                    'mensaje' => 'No se obtuvo el registro'
                )
            );
        }

    } else {
        // Enviar respuesta de error
        print json_encode(
            array(
                'estado' => '3',
                'mensaje' => 'Se necesita un identificador'
            )
        );
    }
}

